﻿namespace BlockChain.Hospital.Data.BlockChain
{
    using global::BlockChain.Hospital.Contract.Policy;
    using global::BlockChain.Hospital.Utils.Helpers;
    using global::BlockChain.Hospital.Utils.Helpers.BlockChain;
    using MediatR;

    public class PolicyBlockChainHandle : IRequestHandler<PolicyBlockChainResponse, int>
    {
        public int Handle(PolicyBlockChainResponse query)
        {
            this.CreateBlockForValidatePolicy(query.PolicyResponse);

            return 1;
        }

        private void CreateBlockForValidatePolicy(Policy policyResponse)
        {
            policyResponse.Event = "Policy match success";
            policyResponse.Policy = policyResponse.PolicyDetails.PolicyId;
            policyResponse.RequestStatus = policyResponse.Status ?  "Success" : "Failure";
            policyResponse.Source = "Green Insurance";

            string senderData = ConvertDataToHex.ConvertDataToHexData(policyResponse);
            var password = "password";

            var blockChainModel = new BlockChainModel
            {
                From = new BlockChainUser
                {
                    Address = Constants.Address["Hospital"],
                    Password = password
                },
                To = new BlockChainUser
                {
                    Address = Constants.Address["Insurer"],
                    Password = password
                },
                Data = senderData
            };

            BlockChainTransaction.CreateTransaction(blockChainModel);            
        }        
    }
}
