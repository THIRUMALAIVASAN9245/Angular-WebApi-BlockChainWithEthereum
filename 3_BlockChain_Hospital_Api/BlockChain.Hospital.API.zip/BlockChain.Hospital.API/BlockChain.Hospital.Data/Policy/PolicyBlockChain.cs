﻿namespace BlockChain.Hospital.Data.BlockChain
{
    using global::BlockChain.Hospital.Contract.Policy;
    using global::BlockChain.Hospital.Utils.Helpers;
    using global::BlockChain.Hospital.Utils.Helpers.BlockChain;
    using MediatR;

    public class PolicyBlockChain : IRequestHandler<PolicyBlockChainRequest, int>
    {
        public int Handle(PolicyBlockChainRequest query)
        {
            this.CreateBlockForValidatePolicy(query.PolicyId);

            return 1;
        }

        private void CreateBlockForValidatePolicy(int PolicyId)
        {
            var policyResponse = new Policy();
            policyResponse.Event = "Policy match";
            policyResponse.Policy = PolicyId;
            policyResponse.RequestStatus =  "Success";
            policyResponse.Source = "Get Well Hospital";

            string senderData = ConvertDataToHex.ConvertDataToHexData(policyResponse);
            var password = "password";

            var blockChainModel = new BlockChainModel
            {
                From = new BlockChainUser
                {
                    Address = Constants.Address["Hospital"],
                    Password = password
                },
                To = new BlockChainUser
                {
                    Address = Constants.Address["Insurer"],
                    Password = password
                },
                Data = senderData
            };

            BlockChainTransaction.CreateTransaction(blockChainModel);            
        }        
    }
}
