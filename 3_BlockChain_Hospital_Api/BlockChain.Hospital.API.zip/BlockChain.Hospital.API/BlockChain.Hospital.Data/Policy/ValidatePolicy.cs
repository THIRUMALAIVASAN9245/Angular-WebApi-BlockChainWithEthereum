﻿namespace BlockChain.Hospital.Data
{
    using Contract.Repository;
    using global::BlockChain.Hospital.Contract.Policy;
    using MediatR;
    using System.Linq;

    public class ValidatePolicy : IRequestHandler<PolicyValidateRequest, Policy>
    {
        private readonly IRepository repository;
        public ValidatePolicy(IRepository repository)
        {
            this.repository = repository;
        }

        public Policy Handle(PolicyValidateRequest query)
        {
            var policy = this.repository.Query<Entities.Policy>().Where(i => i.PolicyId == query.PolicyId && i.IsActive).FirstOrDefault();
            if (policy == null)
            {
                return new Policy
                {
                    Status = false,
                    Message = "Invalid Policy"
                };
            }
            return new Policy
            {
                Status = true,
                PolicyDetails = new PolicyDetails
                {
                    Name = policy.Name,
                    DateofBirth = policy.DateofBirth,
                    Gender = policy.Gender,
                    PolicyStartDate = policy.PolicyStartDate,
                    PolicyId = policy.PolicyId
                }
            };
        }
    }
}
