﻿namespace BlockChain.Hospital.Data.BlockChain
{
    using global::BlockChain.Hospital.Contract.Claim;
    using global::BlockChain.Hospital.Utils.Helpers;
    using global::BlockChain.Hospital.Utils.Helpers.BlockChain;
    using MediatR;

    public class ClaimBlockChainReqestHandle : IRequestHandler<ClaimBlockChainRequest, int>
    {
        public int Handle(ClaimBlockChainRequest query)
        {
            this.CreateBlockForValidateClaim(query.ClaimRequestModel);
            return 1;
        }

        private void CreateBlockForValidateClaim(ClaimRequestModel claimRequestModel)
        {
            claimRequestModel.Event = "Claim details submitted";
            claimRequestModel.Policy = claimRequestModel.PolicyId;
            claimRequestModel.RequestStatus = "Success";
            claimRequestModel.Source = "Get Well Hospital";

            string senderData = ConvertDataToHex.ConvertDataToHexData(claimRequestModel);            
            var password = "password";

            var blockChainModel = new BlockChainModel
            {
                From = new BlockChainUser
                {
                    Address = Constants.Address["Hospital"],
                    Password = password
                },
                To = new BlockChainUser
                {
                    Address = Constants.Address["Insurer"],
                    Password = password
                },
                Data = senderData
            };

            BlockChainTransaction.CreateTransaction(blockChainModel);           
        }        
    }
}
