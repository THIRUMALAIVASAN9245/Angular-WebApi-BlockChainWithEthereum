﻿namespace BlockChain.Hospital.Data
{
    using Contract.Repository;
    using global::BlockChain.Hospital.Contract.Claim;
    using global::BlockChain.Hospital.Utils.Helpers;
    using global::BlockChain.Hospital.Utils.Helpers.BlockChain;
    using MediatR;
    using System.Linq;

    public class ClaimPolicy : IRequestHandler<ClaimRequest, Claim>
    {
        private readonly IRepository repository;
        public ClaimPolicy(IRepository repository)
        {
            this.repository = repository;
        }

        public Claim Handle(ClaimRequest query)
        {
            var policy = this.repository.Query<Entities.Policy>().Where(i => i.PolicyId == query.ClaimRequestModel.PolicyId && i.IsActive).FirstOrDefault();
            Entities.Health health = null;

            var treatmentType = query.ClaimRequestModel.BillDetails.FirstOrDefault();

            if (treatmentType != null && treatmentType.TreatmentType != "Accident")
            {
                health = this.repository.Query<Entities.Health>().Where(i => i.PatientName == policy.Name && i.DiseaseType == query.ClaimRequestModel.Disease && i.TreatmentDate <= policy.PolicyStartDate).FirstOrDefault();

                var healthDataReqest = new Health
                {
                    Event = "Health record fetch",
                    Policy = policy.PolicyId,
                    RequestStatus = "Success",
                    Source = "Global Health Data"
                };

                BlockChainModel blockChainModelReqest = HealthBlockEntryRequest(healthDataReqest);
                BlockChainTransaction.CreateTransaction(blockChainModelReqest);

                var healthData = new Health
                {
                    Event = "Health record fetch success",
                    Policy = policy.PolicyId,
                    RequestStatus = "Success",
                    Source = "Global Health Data"
                };

                if (health != null)
                {
                    healthData.HospitalName = health.HospitalName;
                    healthData.Smoker = health.Smoker;
                    healthData.TreatmentDate = health.TreatmentDate;
                }

                BlockChainModel blockChainModel = HealthBlockEntry(healthData);
                BlockChainTransaction.CreateTransaction(blockChainModel);
            }

            var total = query.ClaimRequestModel.BillDetails.Sum(s => s.BillAmount);
            return new Claim
            {
                BalanceAmount = total > policy.PolicyBenifit ? total - policy.PolicyBenifit : 0,
                ClaimedAmount = total > policy.PolicyBenifit ? policy.PolicyBenifit : total,
                TotalAmount = total,
                Event = "Payment processed",
                Policy = policy.PolicyId,
                RequestStatus = health == null ? "Success" : "Failure",
                Source = "Green Insurance"
            };
        }

        private static BlockChainModel HealthBlockEntryRequest(Health health)
        {
            string senderData = ConvertDataToHex.ConvertDataToHexData(health);
            var password = "password";

            var blockChainModel = new BlockChainModel
            {
                From = new BlockChainUser
                {
                    Address = Constants.Address["Hospital"],
                    Password = password
                },
                To = new BlockChainUser
                {
                    Address = Constants.Address["Health"],
                    Password = password
                },
                Data = senderData
            };
            return blockChainModel;
        }

        private static BlockChainModel HealthBlockEntry(Health health)
        {
            string senderData = ConvertDataToHex.ConvertDataToHexData(health);
            var password = "password";

            var blockChainModel = new BlockChainModel
            {
                From = new BlockChainUser
                {
                    Address = Constants.Address["Hospital"],
                    Password = password
                },
                To = new BlockChainUser
                {
                    Address = Constants.Address["Insurer"],
                    Password = password
                },
                Data = senderData
            };
            return blockChainModel;
        }
    }
}
