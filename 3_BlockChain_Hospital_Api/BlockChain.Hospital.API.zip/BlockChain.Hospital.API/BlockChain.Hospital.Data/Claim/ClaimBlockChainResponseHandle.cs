﻿namespace BlockChain.Hospital.Data.BlockChain
{
    using global::BlockChain.Hospital.Contract.Claim;
    using global::BlockChain.Hospital.Utils.Helpers;
    using global::BlockChain.Hospital.Utils.Helpers.BlockChain;
    using MediatR;

    public class ClaimBlockChainResponseHandle : IRequestHandler<ClaimBlockChainResponse, int>
    {
        public int Handle(ClaimBlockChainResponse query)
        {
            this.CreateBlockForValidateClaim(query.Claim);
            return 1;
        }

        private void CreateBlockForValidateClaim(Claim claimResponse)
        {
            string senderData = ConvertDataToHex.ConvertDataToHexData(claimResponse);            
            var password = "password";

            var blockChainModel = new BlockChainModel
            {
                From = new BlockChainUser
                {
                    Address = Constants.Address["Hospital"],
                    Password = password
                },
                To = new BlockChainUser
                {
                    Address = Constants.Address["Insurer"],
                    Password = password
                },
                Data = senderData
            };

            BlockChainTransaction.CreateTransaction(blockChainModel);           
        }        
    }
}
