﻿using System;

namespace BlockChain.Hospital.Contract.Claim
{
    public class Health : BaseModel
    {
        public string HospitalName { get; set; }        
    
        public string Smoker { get; set; }
        
        public DateTime TreatmentDate { get; set; }
    }
}
