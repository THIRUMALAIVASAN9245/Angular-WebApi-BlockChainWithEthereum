﻿using MediatR;

namespace BlockChain.Hospital.Contract.Claim
{
    public class ClaimBlockChainRequest : IRequest<int>
    {
        public ClaimBlockChainRequest(ClaimRequestModel claimRequestModel)
        {
            ClaimRequestModel = claimRequestModel;
        }
        public ClaimRequestModel ClaimRequestModel { get; set; }
    }
}
