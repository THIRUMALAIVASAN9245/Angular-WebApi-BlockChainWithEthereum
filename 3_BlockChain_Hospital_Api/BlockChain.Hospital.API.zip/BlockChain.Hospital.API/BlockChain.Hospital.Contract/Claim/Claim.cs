﻿namespace BlockChain.Hospital.Contract.Claim
{
    public class Claim: BaseModel
    {
        public bool Status { get; set; }

        public string Message { get; set; }        

        public decimal TotalAmount { get; set; }

        public decimal ClaimedAmount { get; set; }

        public decimal BalanceAmount { get; set; }
    }
}
