﻿using MediatR;

namespace BlockChain.Hospital.Contract.Claim
{
    public class ClaimBlockChainResponse : IRequest<int>
    {
        public ClaimBlockChainResponse(Claim claim)
        {
            Claim = claim;
        }
        public Claim Claim { get; set; }
    }
}
