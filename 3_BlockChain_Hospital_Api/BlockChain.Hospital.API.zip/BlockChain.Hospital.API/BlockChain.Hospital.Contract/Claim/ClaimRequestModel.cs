﻿namespace BlockChain.Hospital.Contract.Claim
{
    using System.Collections.Generic;

    public class ClaimRequestModel : BaseModel
    {
        public int PolicyId { get; set; }

        public string Disease { get; set; }

        public List<BillDetails> BillDetails { get; set; }
    }
}
