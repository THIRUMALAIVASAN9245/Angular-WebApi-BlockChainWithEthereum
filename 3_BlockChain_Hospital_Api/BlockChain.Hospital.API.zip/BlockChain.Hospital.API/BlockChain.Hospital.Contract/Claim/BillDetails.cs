﻿namespace BlockChain.Hospital.Contract.Claim
{
    public class BillDetails
    {
        public string TreatmentType { get; set; }

        public int BillNumber { get; set; }

        public int BillAmount { get; set; }

        public string Description { get; set; }
    }
}
