﻿using System;

namespace BlockChain.Hospital.Contract
{
    public class BaseModel
    {
        public string RequestStatus { get; set; }

        public string Event { get; set; }        

        public string Date { get { return DateTime.Now.ToString("dd-MM-yyyy"); } }

        public string Time { get { return DateTime.Now.ToString("hh:mm:ss tt"); } }

        public int Policy { get; set; }

        public string Source { get; set; }
    }
}
