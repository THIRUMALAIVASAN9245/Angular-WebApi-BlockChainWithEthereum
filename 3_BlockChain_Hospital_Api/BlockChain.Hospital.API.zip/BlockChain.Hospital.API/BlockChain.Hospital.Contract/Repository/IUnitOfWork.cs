﻿namespace BlockChain.Hospital.Contract.Repository
{
    public interface IUnitOfWork
    {
        void Commit();
    }
    
}
