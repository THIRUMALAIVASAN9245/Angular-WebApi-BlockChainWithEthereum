﻿using MediatR;

namespace BlockChain.Hospital.Contract.Policy
{
    public class PolicyBlockChainRequest : IRequest<int>
    {
        public PolicyBlockChainRequest(int policyId)
        {
            PolicyId = policyId;
        }
        public int PolicyId { get; set; }
    }
}
