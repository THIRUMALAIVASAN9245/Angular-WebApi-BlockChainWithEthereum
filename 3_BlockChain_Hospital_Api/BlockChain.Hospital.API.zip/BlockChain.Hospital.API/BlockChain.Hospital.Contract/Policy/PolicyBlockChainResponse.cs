﻿using MediatR;

namespace BlockChain.Hospital.Contract.Policy
{
    public class PolicyBlockChainResponse : IRequest<int>
    {
        public PolicyBlockChainResponse(Policy policyResponse)
        {
            PolicyResponse = policyResponse;
        }
        public Policy PolicyResponse { get; set; }
    }
}
