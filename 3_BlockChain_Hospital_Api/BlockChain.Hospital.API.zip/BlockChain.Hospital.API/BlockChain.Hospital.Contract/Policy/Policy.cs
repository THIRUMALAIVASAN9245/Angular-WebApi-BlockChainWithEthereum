﻿namespace BlockChain.Hospital.Contract.Policy
{
    public class Policy: BaseModel
    {
        public bool Status { get; set; }

        public string Message { get; set; }

        public PolicyDetails PolicyDetails { get; set; }
    }
}
