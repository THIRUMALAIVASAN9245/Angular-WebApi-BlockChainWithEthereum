﻿using BlockChain.Hospital.Infrastructure;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;

namespace OnBoarding.WebAPI.Installers
{
    public class OnBoardingInstaller : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            EntityFrameworkInstaller.Install(container);
            MediatorInstaller.Install(container);
            AutoMapperInstaller.Install(container);
        }
    }
}