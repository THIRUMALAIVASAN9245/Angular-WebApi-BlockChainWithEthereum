﻿using BlockChain.Hospital.Contract.Claim;
using MediatR;
using System.Web.Http;

namespace BlockChain.Hospital.API.Controllers
{
    [RoutePrefix("api/Claim")]
    public class ClaimController : ApiController
    {
        private readonly IMediator mediatr;

        public ClaimController(IMediator mediatr)
        {
            this.mediatr = mediatr;
        }

        [HttpPost]
        [Route("ClaimPolicy")]
        public Claim ClaimPolicy(ClaimRequestModel claimRequestModel)
        {
            this.mediatr.Send(new ClaimBlockChainRequest(claimRequestModel));

            var response = this.mediatr.Send(new ClaimRequest(claimRequestModel));

            this.mediatr.Send(new ClaimBlockChainResponse(response.Result));

            return response.Result;
        }
    
    }
}
