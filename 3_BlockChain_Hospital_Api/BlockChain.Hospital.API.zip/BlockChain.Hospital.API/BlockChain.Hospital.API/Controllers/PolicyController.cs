﻿using BlockChain.Hospital.Contract.Policy;
using MediatR;
using System.Web.Http;

namespace BlockChain.Hospital.API.Controllers
{
    [RoutePrefix("api/Policy")]
    public class PlicyController : ApiController
    {
        private readonly IMediator mediatr;

        public PlicyController(IMediator mediatr)
        {
            this.mediatr = mediatr;
        }

        [HttpGet]
        [Route("Validate/{id}")]
        public Policy Validate(int id)
        {
            var result = this.mediatr.Send(new PolicyBlockChainRequest(id));

            var response = this.mediatr.Send(new PolicyValidateRequest(id));

            if (response?.Result?.PolicyDetails == null)
            {
                response.Result.PolicyDetails = new PolicyDetails { PolicyId = id };
            }

            this.mediatr.Send(new PolicyBlockChainResponse(response.Result));

            return response.Result;
        }
    }
}
