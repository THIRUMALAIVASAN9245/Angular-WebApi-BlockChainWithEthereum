﻿namespace BlockChain.Hospital.EntityContext
{
    using System.Data.Entity.Infrastructure;

    public class DbContextFactory : IDbContextFactory<OnBoardingContext>
    {
        public OnBoardingContext Create()
        {
            return new OnBoardingContext("InsurerNew");
        }
    }
}
