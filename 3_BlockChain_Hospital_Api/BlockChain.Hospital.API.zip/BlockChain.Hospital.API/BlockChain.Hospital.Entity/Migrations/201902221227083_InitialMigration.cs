namespace BlockChain.Hospital.EntityContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialMigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Policy",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        PolicyId = c.Int(nullable: false),
                        Code = c.String(),
                        Premium = c.Decimal(nullable: false, precision: 18, scale: 2),
                        PolicyBenifit = c.Decimal(nullable: false, precision: 18, scale: 2),
                        CreatedOn = c.DateTime(nullable: false),
                        MaturityDate = c.DateTime(nullable: false),
                        IsActive = c.Boolean(nullable: false),
                        Name = c.String(),
                        DateofBirth = c.DateTime(),
                        Gender = c.String(),
                        PolicyStartDate = c.DateTime(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Policy");
        }
    }
}
