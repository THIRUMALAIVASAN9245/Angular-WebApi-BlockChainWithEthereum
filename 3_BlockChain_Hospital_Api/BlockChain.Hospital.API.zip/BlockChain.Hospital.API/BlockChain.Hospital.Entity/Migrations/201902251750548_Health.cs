namespace BlockChain.Hospital.EntityContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Health : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Health",
                c => new
                {
                    Id = c.Guid(nullable: false),
                    MobileNumber = c.Long(nullable: false),
                    HospitalName = c.String(),
                    PatientName = c.String(),
                    DateOfBirth = c.DateTime(),
                    Smoker = c.String(),
                    KnownDisease = c.String(),
                    TreatmentDate = c.DateTime(),
                    DiseaseType = c.String()
                })
                .PrimaryKey(t => t.Id);
        }
        
        public override void Down()
        {
            DropTable("dbo.Health");
        }
    }
}
