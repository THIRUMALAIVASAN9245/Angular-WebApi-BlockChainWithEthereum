namespace BlockChain.Hospital.EntityContext.Migrations
{
    using BlockChain.Hospital.Entities;
    using System;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<BlockChain.Hospital.EntityContext.OnBoardingContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(BlockChain.Hospital.EntityContext.OnBoardingContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            context.Set<Policy>().AddOrUpdate(
             new Policy
             {
                 Code = "POLICY001",
                 CreatedOn = DateTime.Now.AddDays(-100),
                 Id = Guid.NewGuid(),
                 IsActive = true,
                 MaturityDate = DateTime.Now.AddDays(-100),
                 PolicyBenifit = 500000,
                 PolicyId = 12345678,
                 Premium = 5000,
                 Name = "Thirumalai",
                 DateofBirth = DateTime.Now.AddYears(-26),
                 Gender = "Male",
                 PolicyStartDate = DateTime.Now.AddDays(-100),
             },
              new Policy
              {
                  Code = "POLICY002",
                  CreatedOn = DateTime.Now.AddDays(-50),
                  Id = Guid.NewGuid(),
                  IsActive = true,
                  MaturityDate = DateTime.Now.AddDays(-50),
                  PolicyBenifit = 400000,
                  PolicyId = 22345678,
                  Premium = 4000,
                  Name = "Jagadish",
                  DateofBirth = DateTime.Now.AddYears(-26),
                  Gender = "Male",
                  PolicyStartDate = DateTime.Now.AddDays(-100),
              }
            );

        }
    }
}
