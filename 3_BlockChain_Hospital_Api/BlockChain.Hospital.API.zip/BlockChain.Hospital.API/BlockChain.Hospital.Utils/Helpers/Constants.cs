﻿using System.Collections.Generic;

namespace BlockChain.Hospital.Utils.Helpers
{
    public class Constants
    {
        public static Dictionary<string, string> Address = new Dictionary<string, string>
            {
                {"Hospital","0x0084a5c808ede6d87fe4024af4264727342ec189" },
                {"Insurer", "0x37d258d1e6caeccd13cec022d24927628357ed2d" },
                {"Health", "0x0084a5c808ede6d87fe4024af4264727342ec189" }
            };
    }
}
