﻿namespace BlockChain.Hospital.Utils.Helpers.BlockChain
{
    public class BlockChainUser
    {
        public string Address { get; set; }

        public string Password { get; set; }
    }
}
