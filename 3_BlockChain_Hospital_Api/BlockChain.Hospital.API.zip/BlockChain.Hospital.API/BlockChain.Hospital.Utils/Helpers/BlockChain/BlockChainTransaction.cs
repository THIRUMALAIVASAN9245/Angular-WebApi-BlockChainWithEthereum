﻿using Nethereum.Geth;
using Nethereum.RPC.Eth.DTOs;
using Nethereum.Web3;
using System.Threading.Tasks;

namespace BlockChain.Hospital.Utils.Helpers.BlockChain
{
    public class BlockChainTransaction
    {
        public static void CreateTransaction(BlockChainModel blockChainModel)
        {
            string url = "http://127.0.0.1:8101";
            var web3 = new Web3Geth(url);
            web3.Personal.UnlockAccount.SendRequestAsync(blockChainModel.From.Address, blockChainModel.From.Password, 200);
            web3.Personal.UnlockAccount.SendRequestAsync(blockChainModel.To.Address, blockChainModel.To.Password, 200);

            var transactionInput = new TransactionInput
            {
                From = blockChainModel.From.Address,
                To = blockChainModel.To.Address,
                Data = blockChainModel.Data
            };

            web3.Miner.Start.SendRequestAsync();
            var sendTransaction = web3.Eth.Transactions.SendTransaction.SendRequestAsync(transactionInput).Result;
            Task.Delay(5000).Wait();
            var pending = web3.GethEth.PendingTransactions.SendRequestAsync().Result.Length > 0;
            while (pending)
            {
                pending = web3.GethEth.PendingTransactions.SendRequestAsync().Result.Length > 0;
            }            
          
            web3.Miner.Stop.SendRequestAsync();
        }
    }
}
