﻿namespace BlockChain.Hospital.Utils.Helpers.BlockChain
{
    public class BlockChainModel
    {
        public BlockChainUser From { get; set; }

        public BlockChainUser To { get; set; }

        public string Data { get; set; }        
    }
}
