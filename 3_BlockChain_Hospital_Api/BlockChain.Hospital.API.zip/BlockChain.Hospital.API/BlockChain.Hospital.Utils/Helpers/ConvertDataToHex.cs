﻿using System;
using System.Text;
using System.Web.Script.Serialization;

namespace BlockChain.Hospital.Utils.Helpers
{
    public class ConvertDataToHex
    {
        public static string ConvertDataToHexData<T>(T claimResponse) where T : class
        {
            var json = new JavaScriptSerializer().Serialize(claimResponse);
            byte[] claimResponseByte = Encoding.Default.GetBytes(json);
            var senderData = BitConverter.ToString(claimResponseByte);
            senderData = senderData.Replace("-", "");
            return senderData;
        }        
    }
}
