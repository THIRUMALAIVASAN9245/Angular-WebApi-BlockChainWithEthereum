import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const Web3 = require('web3');
declare var window: any;
declare var require: any

@Injectable()
export class Web3Service {

    public web3: any;

    constructor() {
        this.checkAndInstantiateWeb3();
    }

    checkAndInstantiateWeb3 = () => {
        if (typeof window.web3 !== 'undefined') {
            // this.web3 = new Web3(window.web3.currentProvider);
            const httpProvider = new Web3.providers.HttpProvider("http://127.0.0.1:8545");
            this.web3 = new Web3(httpProvider);
        } else {
            const httpProvider = new Web3.providers.HttpProvider("http://127.0.0.1:8545");
            this.web3 = new Web3(httpProvider);
        }
    };

    sendTransactionData(data): any {
        debugger;
        const dataNew = this.getFromTransactionData(data);
        let response;
        this.web3.eth.sendTransaction({
            from: '0x6422a71ef947b368bf4c6bb51091d7095e0f4513',
            data: dataNew // deploying a contract
        }, function (error, hash) {
            response = hash;
        });

        return Observable.create(observer => {
            observer.next(response)
            observer.complete()
        });
    }
    
    getFromTransactionData(data: any): any {
        let response = this.web3.fromAscii(JSON.stringify(data));
        return response;
    }
    
    getTransactionData(data: any): any {
        let response = this.web3.toAscii(data);
        return response;
    }

    getAccountList(): Observable<any> {
        return Observable.create(observer => {
            this.web3.eth.getAccounts((err, accounts) => {
                if (err != null) {
                    observer.error('There was an error fetching your accounts.')
                }

                observer.next(accounts)
                observer.complete()
            });
        });
    }

}